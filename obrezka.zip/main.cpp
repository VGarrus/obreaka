#include <QApplication>
#include <QtWidgets>

class ResizableRect : public QObject, public QGraphicsRectItem
{
public:

    ResizableRect(QGraphicsItem* parent = nullptr) : QGraphicsRectItem(parent), initialPos(QPointF(0, 0)), imageItem(nullptr), croppedImageItem(nullptr)
    {
        setRect(0, 0, 100, 100); // Установка начальных размеров прямоугольника
        setPen(Qt::DashLine); // Установка стиля отображения рамки
        setBrush(Qt::NoBrush); // Установка отсутствия заливки
        setFlag(QGraphicsItem::ItemIsMovable); // Установка возможности перемещения прямоугольника
        setFlag(QGraphicsItem::ItemIsSelectable); // Установка возможности выбора прямоугольника
    }

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent* event) override
    {
        initialPos = event->scenePos(); // Запоминание начальной точки при нажатии кнопки мыши
        QGraphicsRectItem::mousePressEvent(event); // Вызов метода базового класса при нажатии кнопки мыши
    }

    void mouseReleaseEvent(QGraphicsSceneMouseEvent* event) override
    {
        QRectF selectedRect = rect(); // Получение области выделения
        if (!selectedRect.isNull() && imageItem)
        {
            QImage selectedImage = imageItem->pixmap().toImage().copy(selectedRect.toRect()); // Выделение выбранной области изображения
            selectedImage.save("selected_image.png"); // Сохранение обрезанного изображения в файл

            // Удаление предыдущего обрезанного изображения, если оно существует
            if (croppedImageItem)
            {
                scene()->removeItem(croppedImageItem);
                delete croppedImageItem;
            }

            // Отображение орезанного изображения
            croppedImageItem = scene()->addPixmap(QPixmap::fromImage(selectedImage));
            croppedImageItem->setPos(0, imageItem->pixmap().height());
        }
        QGraphicsRectItem::mouseReleaseEvent(event); // Вызов метода базового класса при отпускании кнопки мыши
    }

    void mouseMoveEvent(QGraphicsSceneMouseEvent* event) override
    {
        auto newPos = event->scenePos(); // Получение новой позиции курсора
        if (event->buttons() & Qt::LeftButton && (initialPos.x() != newPos.x() || initialPos.y() != newPos.y()))
        {
            setRect(QRectF(initialPos, newPos)); // Изменение размеров прямоугольника при перемещении мыши
        }
        else
        {
            QGraphicsRectItem::mouseMoveEvent(event); // Вызов метода базового класса при перемещении мыши
        }
    }

public:
    QPointF initialPos; // Начальная позиция прямоугольника
    QGraphicsPixmapItem* imageItem; // Указатель на изображение
    QGraphicsPixmapItem* croppedImageItem; // Указатель на обрезанное изображение
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // Загрузка изображения
    QImage image("C:/Users/artem/OneDrive/Documents/untitled1/initial_image.png");

    // Создание сцены и добавление изображения
    QGraphicsScene scene;
    QGraphicsPixmapItem* imageItem = scene.addPixmap(QPixmap::fromImage(image));

    // Создание изменяемого прямоугольника
    ResizableRect* resizableRect = new ResizableRect;
    resizableRect->imageItem = imageItem; // Установка изображения в изменяемый прямоугольник
    scene.addItem(resizableRect);

    // Создание виджета для отображения сцены
    QGraphicsView view(&scene);
    view.show();

    return app.exec();
}
